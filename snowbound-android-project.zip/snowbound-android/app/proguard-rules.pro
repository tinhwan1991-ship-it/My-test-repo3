# No app-specific ProGuard rules are needed for the current WebView wrapper.
